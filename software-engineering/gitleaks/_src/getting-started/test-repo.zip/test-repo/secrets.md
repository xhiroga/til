# Secrets

## AWS environment varialbes

```shell
export AWS_ACCESS_KEY_ID="AKIAIMNOJVGFDXXXE4OA"
export AWS_SECRET_ACCESS_KEY="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"
export AWS_SESSION_TOKEN=""
```

### Reference

[5bEYu26084qjSFyclM/f2pz4gviSfoOg\+mFwBH39](https://summitroute.com/blog/2018/06/20/aws_security_credential_formats/)
